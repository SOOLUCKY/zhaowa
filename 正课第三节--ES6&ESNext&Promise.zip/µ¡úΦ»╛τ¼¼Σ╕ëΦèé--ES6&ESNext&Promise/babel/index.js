
const fn = () => 1;

